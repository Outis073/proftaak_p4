<?php
    require_once ('Model.php');

    class User extends Model {
        protected $id;
        protected $email;
        protected $firstName;
        protected $lastName;
        protected $street;
        protected $houseNumber;
        protected $postalCode;
        protected $city;
        protected $telephone;
        protected $password;
        
        //protected $authenticated;

        public function __construct(string $email = '', string $firstName = '', string $lastName = '', string $street = '', string $houseNumber = '', 
                                    string $postalCode = '', string $city = '', string $telephone = '', string $password = '', string $passwordCheck = '') {

            $this->email = $email;
            $this->firstName = $firstName;
            $this->lastName = $lastName;
            $this->street = $street;
            $this->houseNumber = $houseNumber;
            $this->postalCode = $postalCode;
            $this->city = $city;
            $this->telephone = $telephone;
            $this->password = $password;
            $this->passwordCheck = $password;
            //$this->authenticated = FALSE;

        }

        public function register() : int {
            $pdo = DB::connect();	

            $query = 'INSERT INTO users (email, password_hash, active) VALUES (:email, :password, 1)';
                
            try
                {
                    $stmt = $pdo->prepare($query);
                    $stmt->execute([
                        ':email' => $this->email, 
                        ':password' => $this->password
                    ]);
                } catch (PDOException $e) {
                    throw new Exception('Database query error');
                }

            return $pdo->lastInsertId();
        }

        public static function login($email, $password){

            $pdo = DB::connect();

            $query = 'SELECT * FROM users WHERE email = :email';
            $stmt = $pdo->prepare($query);

            $stmt->execute([
                ':email' => $email
            ]);

            $row = $stmt->fetch(PDO::FETCH_OBJ);
            $hashed_password = $row->password_hash;

            if(password_verify($password,$hashed_password)) {
                return $row;
            } else {
                return false;
            }


        }

        // Find user by email
        public static function findUserByEmail($email){

            $pdo = DB::connect();
            
            $query = 'SELECT * FROM users WHERE email = :email';
            $stmt = $pdo->prepare($query);

            $stmt->execute([
                ':email' => $email
            ]);

            // Check Row
            if($stmt->rowCount() > 0){
                return true;
            } else {
                return false;
            }
        }
        
    }

   