<?php require_once ('incl/header.php'); ?>

    <div class="jumbotron jumbotron-flud text-center">
        <div class="container">
            <h1 class="display-3"><?= $title; ?></h1>
            <p class="lead"><?= $content; ?></p>
        </div>
    </div>

<?php require_once ('incl/footer.php'); ?>


