<?php
    
    require ('./Models/User.php');

    class UserController {
        public function index() {
            // Welke pagina tonen??? u login pagina
            $view = new View('User/login');
            $view->set('title','Gebruiker');
            $view->set('content','Gebruikerspagina');

            //$view->render();
        }

        public function register() {
            
            $view = new View('User/register');
            $view->set('title','Registreer');
            $view->set('content','Registreer als nieuwe klant');

            // Controleer of er een POST is binnengekomen anders leeg formulier tonen
            if($_SERVER['REQUEST_METHOD'] == 'POST') {

                // Controleer het ingevulde formulier

                // "Sanitize" de POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                // Initialiseer een array met data om te valideren en eventueel error messages aan te maken
                $data = [
                    'email' => trim($_POST['email']),
                    'firstName' => trim($_POST['firstName']),
                    'lastName' => trim($_POST['lastName']),
                    'street' => trim($_POST['street']),
                    'houseNumber' => trim($_POST['houseNumber']),
                    'postalCode' => trim($_POST['postalCode']),
                    'city' => trim($_POST['city']),
                    'telephone' => trim($_POST['telephone']),
                    'password' => trim($_POST['password']),
                    'passwordCheck' => trim($_POST['passwordCheck']),
                    'email_err' => '',
                    'firstName_err' => '',
                    'lastName_err' => '',
                    'street_err' => '',
                    'houseNumber_err' => '',
                    'postalCode_err' => '',
                    'city_err' => '',
                    'telephone_err' => '',
                    'password_err' => '',
                    'passwordCheck_err' => ''
                ];
             
                // Valideer Email
                $data['email'] = filter_var($data['email'], FILTER_SANITIZE_EMAIL);

                if(empty($data['email'])) {
                    $data['email_err'] = 'Vul aub email adres in';
                } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false){
                    $data['email_err'] = 'Onvolledig email adres, gebruik @ en .';
                } else {
                    // Check of email adres al voorkomt in de database (email moet uniek zijn)
                    if(User::findUserByEmail($data['email'])) {
                        $data['email_err'] = 'Email al in gebruik';
                    }
                }

                // Valideer firstName
                if(empty($data['firstName'])) {
                    $data['firstName_err'] = 'Vul aub voornaam in';
                }

                // Valideer lastName
                if(empty($data['lastName'])) {
                    $data['lastName_err'] = 'Vul aub achternaam in';
                }

                // Valideer street
                if(empty($data['street'])) {
                    $data['street_err'] = 'Vul aub woonplaats in';
                }

                // Valideer houseNumber
                if(empty($data['houseNumber'])) {
                    $data['houseNumber_err'] = 'Vul aub huisnummer in';
                }

                // Valideer postalCode
                if(empty($data['postalCode'])) {
                    $data['postalCode_err'] = 'Vul aub postcode in';
                }

                // Valideer city
                if(empty($data['city'])) {
                    $data['city_err'] = 'Vul aub woonplaats in';
                }

                // Valideer telephone
                if(empty($data['telephone'])) {
                    $data['telephone_err'] = 'Vul aub telefoonnummer in';
                }
              
                // Valideer wachtwoord
                // Moet bestaan uit minimaal 6 karakters, kleine letters, hoofdletters en cijfers
                if(empty($data['password'])) {
                    $data['password_err'] = 'Vul aub wachtwoord in';
                } elseif ((strlen($data['password'])) < 6) {
                    $data['password_err'] = 'Wachtwoord moet minimaal 6 karakters zijn';
                } elseif (!preg_match("#[0-9]+#", $data['password'] )) {
                    $data['password_err'] = 'Wachtwoord moet een cijfer bevatten';
                } elseif (!preg_match("#[a-z]+#", $data['password'] )) {
                    $data['password_err'] = 'Wachtwoord moet een letter bevatten';
                } elseif (!preg_match("#[A-Z]+#", $data['password'] )) {
                    $data['password_err'] = 'Wachtwoord moet een hoofdletter bevatten';
                } 

                // Valideer controle Password
                if(empty($data['passwordCheck'])) {
                    $data['passwordCheck_err'] = 'Vul aub wachtwoord ter controle in';
                } else {
                    if($data['password'] != $data['passwordCheck']) {
                        $data['passwordCheck_err'] = 'Wachtwoorden zijn niet gelijk';
                    }
                }
                
                // Wanneer er geen errors zijn kan de user data naar de database toe
                if(empty($data['email_err']) && empty($data['firstName_err']) && empty($data['lastName_err']) 
                && empty($data['street_err']) && empty($data['houseNumber_err']) && empty($data['postalCode_err'])
                && empty($data['city_err']) && empty($data['telephone_err'])
                && empty($data['password_err']) && empty($data['passwordCheck_err'])) {
                    
                    // Formulier is ok, geen error in de invoer
                    
                    // Het Password versleutelen (hash)
                    $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

                    // Registreer de gebruiker
                    $user = new User($data['email'], $data['firstName'], $data['lastName'], $data['street'], $data['houseNumber'], 
                                     $data['postalCode'], $data['city'], $data['telephone'], $data['password']);

                    
                    if($user->register()) {
                        flash('register_success','Registratie geslaagd. U kunt nu inloggen');
                        
                        header("Location: index.php?controller=user&action=login");

                    } else {
                        die('Error. Er is iets fout gegaan!!!');
                    }; 

                } else {
                    // Wanneer er errors in de input is, laat je de registratie pagina opnieuw zien
                    $view->set('email',$data['email']);
                    $view->set('firstName',$data['firstName']);
                    $view->set('lastName',$data['lastName']);
                    $view->set('street',$data['street']);
                    $view->set('houseNumber',$data['houseNumber']);
                    $view->set('postalCode',$data['postalCode']);
                    $view->set('city',$data['city']);
                    $view->set('telephone',$data['telephone']);
                    $view->set('password',$data['password']);
                    $view->set('passwordCheck',$data['passwordCheck']);

                    $view->set('email_err',$data['email_err']);
                    $view->set('firstName_err',$data['firstName_err']);
                    $view->set('lastName_err',$data['lastName_err']);
                    $view->set('street_err',$data['street_err']);
                    $view->set('houseNumber_err',$data['houseNumber_err']);
                    $view->set('postalCode_err',$data['postalCode_err']);
                    $view->set('city_err',$data['city_err']);
                    $view->set('telephone_err',$data['telephone_err']);
                    $view->set('password_err',$data['password_err']);
                    $view->set('passwordCheck_err',$data['passwordCheck_err']);
                    
                    $view->render();

                }

            } else {
                // Wanneer er nog geen POST is (eerste keer formulier openen), laat je een pagina met een leeg formulier zien

                // Array voor de data creëren
                $data = [
                    'email' => '',
                    'firstName' => '',
                    'lastName' => '',
                    'street' => '',
                    'houseNumber' => '',
                    'postalCode' => '',
                    'city' => '',
                    'telephone' => '',
                    'password' => '',
                    'passwordCheck' => '',
                    'email_err' => '',
                    'firstName_err' => '',
                    'lastName_err' => '',
                    'street_err' => '',
                    'houseNumber_err' => '',
                    'postalCode_err' => '',
                    'city_err' => '',
                    'telephone_err' => '',
                    'password_err' => '',
                    'passwordCheck_err' => ''
                ];

                // Variabelen instellen (leeg) en formulier tonen
                $view->set('email',$data['email']);
                $view->set('firstName',$data['firstName']);
                $view->set('lastName',$data['lastName']);
                $view->set('street',$data['street']);
                $view->set('houseNumber',$data['houseNumber']);
                $view->set('postalCode',$data['postalCode']);
                $view->set('city',$data['city']);
                $view->set('telephone',$data['telephone']);
                $view->set('password',$data['password']);
                $view->set('passwordCheck',$data['passwordCheck']);
                
                $view->render();
            }
        }

        public function login() {
            $view = new View('User/login');
            $view->set('title','Login');
            $view->set('content','Vul uw login gegevens in om aan te melden');

            // Controleer of er een POST is binnengekomen anders leeg formulier tonen
            if($_SERVER['REQUEST_METHOD'] == 'POST') {
                
                // Controleer het ingevulde formulier

                // "Sanitize" de POST data
                $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                // Initialiseer een array met data om te valideren en eventueel error messages aan te maken
                $data = [
                    'email' => trim($_POST['email']),
                    'password' => trim($_POST['password']),
                    'email_err' => '',
                    'password_err' => '',
                ];

                // Valideer Email
                $data['email'] = filter_var($data['email'], FILTER_SANITIZE_EMAIL);

                if(empty($data['email'])) {
                    $data['email_err'] = 'Vul aub email adres in';
                } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) === false){
                    $data['email_err'] = 'Onvolledig email adres, gebruik @ en .';
                }

                // Valideer controle Password
                if(empty($data['password'])) {
                    $data['password_err'] = 'Vul aub wachtwoord in';
                }

                // Controleer of gebruiker/email in de database voorkomt
                if(User::findUserByEmail($data['email'])) {
                    // Gebruiker gevonden
                } else {
                    // Geen gebruiker gevonden
                    $data['email_err'] = 'Geen gebruiker gevonden';
                }


                // Wanneer er geen errors zijn kan de user data naar de database toe
                if(empty($data['email_err']) && empty($data['password_err'])) {
                    
                    // Formulier is ok, geen error in de invoer

                    // Inloggen gebruiker
                    $loggedInUser = User::login($data['email'],$data['password']);

                    if($loggedInUser){
                        // Create Session
                        $this->createUserSession($loggedInUser);

                    } else {
                        $data['password_err'] = 'Wachtwoord niet correct';

                        $view->set('email',$data['email']);
                        $view->set('password',$data['password']);
                        
                        $view->set('email_err',$data['email_err']);
                        $view->set('password_err',$data['password_err']);
                        
                        $view->render();
                    }
                    



                } else {

                    // Init data
                    // Wanneer er errors in de input is, laat je de registratie pagina opnieuw zien
                    $view->set('email',$data['email']);
                    $view->set('password',$data['password']);
                    
                    $view->set('email_err',$data['email_err']);
                    $view->set('password_err',$data['password_err']);
                    
                    $view->render();
                }

            } else {
                // Wanneer er nog geen POST is (eerste keer formulier openen), laat je een pagina met een leeg login formulier zien             

                // Array voor de data creëren
                $data = [
                    'email' => '',
                    'password' => '',
                    'email_err' => '',
                    'password_err' => '',
                ];

                // Variabelen instellen (leeg) en formulier tonen
                $view->set('email',$data['email']);
                $view->set('password',$data['password']);

                $view->render();
            }

        }

        public function createUserSession($user){
            $_SESSION['user_id'] = $user->id;
            $_SESSION['user_email'] = $user->email;
            $_SESSION['user_name'] = $user->name;

            header("Location: index.php?controller=Home");


        }

        public function logout(){
            unset($_SESSION['user_id']);
            unset($_SESSION['user_email']);
            unset($_SESSION['user_name']);

            session_destroy();

            header("Location: index.php?controller=Home");
        }

        public function isLoggedIn(){
            if(isset($_SESSION['user_id'])){
                return true;
            } else {
                return false;
            }
        }

        public function isAdmin(){
            if($_SESSION['user_type'] === 'Admin'){
                return true;
            } else {
                return false;
            }
        }

    }